function z=FunCost(x,FunNumber)



z=All_Fun(x,FunNumber);


end