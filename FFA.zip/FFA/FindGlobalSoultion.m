function [GlobalMem,PopMain,CostMain]=FindGlobalSoultion(Section,Nvar,n,CGlobal,GlobalMem)

PopMain=[];
CostMain=[];
% merage all section Position and Cost
% all soultion copy to pop
% all fit copy to Cost
for s=1:numel(Section)
 PopSection=[Section{s}.Pop.Position];
 PopMain=[PopMain;reshape(PopSection,n,Nvar)];
 CostMain=[CostMain [Section{s}.Pop(1:end).Cost]]; 
end

% sort for select CGlobal first index
[~,idx]=sort(CostMain);

% copy best Solution to GlobalMem
for i=1:CGlobal   
    GlobalMem(i).Position=PopMain(idx(i),:);
    GlobalMem(i).Cost=CostMain(idx(i)); 
end



end