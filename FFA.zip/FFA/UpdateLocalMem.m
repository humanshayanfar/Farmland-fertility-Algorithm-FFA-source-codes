function Section=UpdateLocalMem(Section,k,CLocal)

  for s=1:k
      [~,idx]=sort([Section{s}.Pop.Cost]);
      for i=1:CLocal
          Section{s}.LocalMem=idx(1:CLocal);    
      end
      
  end

end