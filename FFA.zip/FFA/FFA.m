%___________________________________________________________________%
%  Farmland fertility Algorithm (FFA) source codes version 1.0      %
%                                                                   %
%  Developed in MATLAB R2017a                                       %
%                                                                   %
%  Author and programmer:                                           %
%                       Human Shayanfar                             %
%                       Farhad Soleimanian Gharehchopogh            %
%                                                                   %
%  e-Mail: humanshayanfar@yahoo.com                                 %
%          bonab.farhad@gmail.com                                   %
%                                                                   %
%                                                                   %
%   Main paper:                                                     %
%               Farmland fertility: A new metagheuristic algorithm  %  
%               for solvin continuous optimization problems,        %
%                Applied Soft Computing                             %
%               https://doi.org/10.1016/j.asoc.2018.07.033          %
%                                                                   %
%___________________________________________________________________%
%% parameters setting and Problem Definition
VarMin=-10;
VarMax=10;
Nvar=20;
FunNumber=1;
CostFunction=@(x) FunCost(x,1);        % Cost Function
VarSize=[1 Nvar];   % Decision Variables Matrix Size
%% FFA setting
MaxIt=100;              % Maximum Number of Iterations
k=2;                    % k determines the number of section .Eq(1)
n=50;                   % Number of solutions in each section.Eq(1)
NPop=k*n;               % Population Size (N in base Article)
alpha=0.6;               % A number between 0 and 1.Eq(9)
betha=0.4;              % A number between 0 and 1.Eq(10)
W=1;                    % an integer .Eq(14)
Q=0.5;                  % A number between 0 and 1.Eq(14)
%% Initialization:. First stage: initial values

% Empty Farmland Structure
EmptyFarmland.Position=[];
EmptyFarmland.Cost=inf;

% Initialize Population Array
pop=repmat(EmptyFarmland,NPop,1);

% Create Initial Population
for i=1:NPop
    
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Cost=CostFunction(pop(i).Position);

end

% section soulation
RandIdx=randsample(NPop,NPop);
Section=cell(1,k);
for s=1:k
    aj=n*(s-1)+1:n*s;
    Section{s}.Pop=pop(RandIdx(aj));
    Section{s}.LocalMem=[];
end


% Array to Hold Best Cost Values
BestSol.Cost=inf;
BestSol.Position=[];
BestCost=zeros(MaxIt,1);



%% Main Loop
 for It=1:MaxIt

  % Second stage: determining soil quality in each part of farmland
  FitSection=inf(1,k);
  for s=1:k
     FitSection(s)=mean([Section{s}.Pop.Cost]); 
  end

  
  % Third stage: update memories
  t=0.02;% Eq(7)
  CLocal=round(t*n);% Eq(7)  Count soulation in Local  Memory  
  Section=UpdateLocalMem(Section,k,CLocal);
  CGlobal=round(t*NPop);% Eq(8) Count soulation in Global Memory
  GlobalMem=repmat(EmptyFarmland,CGlobal,1);
  [GlobalMem,PopMain,CostMain]=FindGlobalSoultion(Section,Nvar,n,CGlobal,GlobalMem);% Find Global Soultion 
  
 
  % Fourth stage: changing soil quality in each part of farmland
  [~,idx]=max(FitSection);
  %
  for s=1:k
      
      if (s==idx)% worst sections
          %...................................................
          for i=1:n
              h=alpha*unifrnd(-1,+1,VarSize);%Eq(9)
              Xij=Section{s}.Pop(i).Position;
              XGlobal=GlobalMem(randi([1 CGlobal],1)).Position;% Rand select GlobalMem randi([1 CGlobal],1)
              Xnew=h.*(Xij-XGlobal)+Xij;%Eq(10)  
              Xnew=max(Xnew,VarMin);
              Xnew=min(Xnew,VarMax);
              FitNew=CostFunction(Xnew);
              if(FitNew<=Section{s}.Pop(i).Cost)
                  Section{s}.Pop(i).Position=Xnew;
                  Section{s}.Pop(i).Cost=FitNew;      
                  
              end
          end
     
      else        % other sections
          %++++++++++++++++++++++++++++++++++++++++++++++++++++
          for i=1:n
              h=betha*unifrnd(-1,1,VarSize);%Eq(11)
              Xij=Section{s}.Pop(i).Position;
              Xuj=PopMain(randi([1 NPop],1),:);         
              Xnew=h.*(Xij-Xuj)+Xij;%Eq(12)  
              Xnew=max(Xnew,VarMin);
              Xnew=min(Xnew,VarMax);
              FitNew=CostFunction(Xnew);
              if(FitNew<=Section{s}.Pop(i).Cost)
                  Section{s}.Pop(i).Position=Xnew;
                  Section{s}.Pop(i).Cost=FitNew;    
              end
             
          end  
    
      end

  end% end Fourth stage

  Section=UpdateLocalMem(Section,k,CLocal); 
  

   % Fifth stage: soil�s combination
   for s=1:k
       for i=1:n
           
           if(Q>rand)
               W=W*0.1;%Eq(14)
               Xij=Section{s}.Pop(i).Position;
               b=randi([1 CGlobal],1);
               XGlobal=GlobalMem(b).Position;% 
               Xnew=unifrnd(-1,+1,VarSize).*(Xij-XGlobal)+Xij;%Eq(13) 
               Xnew=max(Xnew,VarMin);
               Xnew=min(Xnew,VarMax);
               FitNew=CostFunction(Xnew);
              if(FitNew<=Section{s}.Pop(i).Cost)
                  Section{s}.Pop(i).Position=Xnew;
                  Section{s}.Pop(i).Cost=FitNew;    
              end
           
           else
                          
               Xij=Section{s}.Pop(i).Position;
               b=randi([1 CLocal],1);
               idxlocal=Section{s}.LocalMem(b);
               XLocal=Section{s}.Pop(idxlocal).Position;
               Xnew=unifrnd(-1,+1,VarSize).*(Xij-XLocal)+Xij;%Eq(13)   
               Xnew=max(Xnew,VarMin);
               Xnew=min(Xnew,VarMax);
               FitNew=CostFunction(Xnew);
               if(FitNew<=Section{s}.Pop(i).Cost)
                  Section{s}.Pop(i).Position=Xnew;
                  Section{s}.Pop(i).Cost=FitNew;    
               end
       
           end
          
       end
   
   end% end Fifth stage

     
  % show Best Global 
   GlobalFind=FindGlobalSoultion(Section,Nvar,n,CGlobal,GlobalMem);% Find Global Soultion 
   if(GlobalFind(1).Cost<BestSol.Cost)
       BestSol.Cost=GlobalFind(1).Cost;
       BestSol.Position=GlobalFind(1).Position;
   end
    % Store Best Cost
    BestCost(It)=BestSol.Cost;
    % Display Iteration Information
    disp(['Iteration ' num2str(It) ': Best Cost = ' num2str(BestCost(It))]);

end

%% Results

minresult=BestCost(end);

if(Flag)

    plot(BestCost,'k-','LineWidth',1);
end






